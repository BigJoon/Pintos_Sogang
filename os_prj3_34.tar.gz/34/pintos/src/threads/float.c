#define FRACTION (1<<14)

int I_SUB_F(int i, int f){
    int result;
    result = i * FRACTION - f;
    return result;
}

int I_MUL_F(int i, int f){
    int result;
    result = i * f;
    return result;
}

int F_ADD_I(int f, int i){
    int result;
    result = f + i * FRACTION;
    return result;
}

int F_MUL_F(int f, int i){
    int64_t temp = f;
    temp = temp * i / FRACTION;
    return (int)temp;
}

int F_DIV_F(int f1, int f2){
    int64_t temp = f1;
    temp = temp * FRACTION / f2;
    return (int)temp;
}

int F_ADD_F(int f1, int f2){
    int result;
    result = f1 + f2;
    return result;
}

int F_SUB_F(int f1, int f2){
    int result;
    result = f1- f2;
    return result;
}

int F_DIV_I(int f, int i){
    int result;
    result = f / i;
    return result;
}
