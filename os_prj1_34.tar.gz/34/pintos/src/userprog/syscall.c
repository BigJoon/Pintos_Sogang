#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"

static void syscall_handler (struct intr_frame *);

void
syscall_init (void) 
{
  intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

static void
syscall_handler (struct intr_frame *f UNUSED) 
{
  switch(*(uint32_t*)(f->esp)){
         case SYS_HALT:
             halt();
             break;
         case SYS_EXIT:
            check_user_vaddr(f->esp+4);
            exit(*(uint32_t*)(f->esp+4));
            break;
         case SYS_EXEC:
            check_user_vaddr(f->esp + 4);
            f->eax = exec((const char*)*(uint32_t*)(f->esp+4));
            break;
         case SYS_WAIT:
            check_user_vaddr(f->esp + 4);
            f->eax = wait((pid_t)*(uint32_t*)(f->esp+4));
            break;
         case SYS_CREATE:
            break;
         case SYS_REMOVE:
            break;
         case SYS_OPEN:
            break;
         case SYS_FILESIZE:
            break;
         case SYS_READ:
            check_user_vaddr(f->esp +20);
            check_user_vaddr(f->esp +24);
            check_user_vaddr(f->esp +28);
            read((int)*(uint32_t*)(f->esp+20), (void*)*(uint32_t*)(f->esp+24), (unsigned)*((uint32_t*)(f->esp+28)));
            break;
         case SYS_WRITE:
            f->eax = write((int)*(uint32_t*)(f->esp+4), (void*)*(uint32_t*)(f->esp+8),(unsigned)*((uint32_t*)(f->esp+12))); 
            break;
         case SYS_SEEK:
            break;
         case SYS_TELL:
            break;
         case SYS_CLOSE:
            break;
         case SYS_PIBONACCI:
            f->eax = pibonacci((pid_t)*(uint32_t*)(f->esp+4));
            break;
         case SYS_SUM: 
            f->eax = sum_of_four_integers((pid_t)*(uint32_t*)(f->esp+4), (pid_t)*(uint32_t*)(f->esp+8), (pid_t)*(uint32_t*)(f->esp+12), (pid_t)*(uint32_t*)(f->esp+16));
            break;
  }
}


void halt(void){
    shutdown_power_off();
}

void exit(int status){
    struct thread *t;

    t = thread_current();
    t->c.dead_status = status;
    t->parent_thread->c.child_dead = status;
    printf("%s: exit(%d)\n", thread_name(), status);
    thread_exit();
}


pid_t exec(const char *cmd_line){
    struct thread *exec_thread;
    void *tmp;

    exec_thread = thread_current();
    tmp = pagedir_get_page(exec_thread->pagedir, cmd_line);
    
    (tmp == NULL) ? exit(-1) : (tmp = NULL);
    return process_execute(cmd_line);
}

int wait(pid_t pid){
    return process_wait(pid);
}


int read(int fd, void *buffer, unsigned size){
    int i=0;
    if(fd==0){
        for(i=0;i<(signed)size;i++){
            if(((char*)buffer)[i] == '\0'){
                break;
            }
        }
    }
    return i;
}

int write(int fd, const void *buffer, unsigned size){
    if (fd == 1){
        putbuf(buffer,size);
        return size;
    }
    return -1;
}

void check_user_vaddr(const void *vaddr){
    if(!is_user_vaddr(vaddr)){
        exit(-1);
    }
}

int pibonacci(int n){
    if(n==0)
        return 0;
    else if(n==1)
        return 1;
    else
        return pibonacci(n-1) + pibonacci(n-2);
}

int sum_of_four_integers(int a,int b,int c,int d){
    return a+b+c+d;
}
