#include <stdio.h>
#include <syscall.h>

int main(int argc, char **argv)
{
    int i,j;
    int num[4];
    int pibonacci_result, sum_result;
    int temp;
 
    for(i=0;i<4;i++){
        temp =0;
        for(j=0;argv[i+1][j]!= '\0';j++){
            temp *= 10;
            temp += argv[i+1][j]-'0';
        }
        num[i] = temp;
    }

    pibonacci_result = pibonacci(num[0]);
    sum_result = sum_of_four_integers(num[0], num[1], num[2], num[3]);

    printf("%d %d\n", pibonacci_result, sum_result);
    
    return EXIT_SUCCESS;
}
