#include "userprog/syscall.h"
#include <stdio.h>
#include <syscall-nr.h>
#include "threads/interrupt.h"
#include "threads/thread.h"
#include "threads/malloc.h"
#include "devices/shutdown.h"
#include "userprog/process.h"
#include "threads/vaddr.h"
#include "userprog/pagedir.h"
#include "filesys/filesys.h"
#include "filesys/file.h"
#include "filesys/inode.h"
#include "threads/synch.h"

struct file{
    struct inode *inode;
    off_t pos;
    bool deny_write;
};


static void syscall_handler (struct intr_frame *);

    void
syscall_init (void) 
{
    intr_register_int (0x30, 3, INTR_ON, syscall_handler, "syscall");
}

    static void
syscall_handler (struct intr_frame *f UNUSED) 
{
    int *pesp;
    int i;
    pesp = f->esp;
    switch(*(uint32_t*)(f->esp)){
        case SYS_HALT:
            halt();
            break;
        case SYS_EXIT:
            check_user_vaddr(f->esp+4);
            for(i=0; i<128; i++)
                if(thread_current()->fd[i] != NULL) close(i);
            thread_exit(*(uint32_t*)(f->esp+4));
            break;
        case SYS_EXEC:
            check_user_vaddr(f->esp + 4);
            f->eax = exec(*(const char**)(f->esp+4));
            break;
        case SYS_WAIT:
            check_user_vaddr(f->esp + 4);
            f->eax = wait((pid_t)*(uint32_t*)(f->esp+4));
            break;
        case SYS_CREATE:
            check_user_vaddr(f->esp + 4);
            check_user_vaddr(f->esp + 8);
            f->eax = syscall_create((const char*)*(uint32_t*)(f->esp+4),  (unsigned)*((uint32_t*)(f->esp+8)));
            break;
        case SYS_REMOVE:
            lock_acquire(&file_lock);
            f->eax = filesys_remove(*(pesp+1));
            lock_release(&file_lock);
            break;
        case SYS_OPEN:
            f->eax = open(*(const char**)(pesp+1));
            break;
        case SYS_FILESIZE:
            f->eax = filesize(*(pesp+1));
            break;
        case SYS_READ:
            check_user_vaddr(f->esp + 4);
            check_user_vaddr(f->esp + 8);
            check_user_vaddr(f->esp + 12); 
            f->eax = read(*(int*)(pesp+1), *(void**)(pesp+2), *(uint32_t*)(pesp+3));
            break;
        case SYS_WRITE:
            check_user_vaddr(f->esp + 4);
            check_user_vaddr(f->esp + 8);
            check_user_vaddr(f->esp + 12);
            f->eax = write(*(pesp+1), *(pesp+2), *(pesp+3));
            break;
        case SYS_SEEK:
            lock_acquire(&file_lock);
            file_seek(thread_current()->fd[*(int*)(pesp+1)], *(pesp+2));
            lock_release(&file_lock);
            break;
        case SYS_TELL:
            lock_acquire(&file_lock);
            file_tell(thread_current()->fd[(*(pesp+1))]);
            lock_release(&file_lock);
            break;
        case SYS_CLOSE:
            close(*(uint32_t*)(f->esp+4));
            break;
        case SYS_PIBONACCI:
            f->eax = pibonacci((pid_t)*(uint32_t*)(f->esp+4));
            break;
        case SYS_SUM: 
            f->eax = sum_of_four_integers((pid_t)*(uint32_t*)(f->esp+4), (pid_t)*(uint32_t*)(f->esp+8), (pid_t)*(uint32_t*)(f->esp+12), (pid_t)*(uint32_t*)(f->esp+16));
            break;
    }
}


void halt(void){
    shutdown_power_off();
}

pid_t exec(const char *cmd_line){
    struct thread *exec_thread;
    void *tmp;

    exec_thread = thread_current();
    tmp = pagedir_get_page(exec_thread->pagedir, cmd_line);
    
    (tmp == NULL) ? thread_exit(-1) : (tmp = NULL);
    return process_execute(cmd_line);
}

int wait(pid_t pid){
    return process_wait(pid);
}

int read(int fd, void *buffer, unsigned size){ 
    int i=0;
    
    lock_acquire(&file_lock);

    if(fd == STDIN_FILENO){
        while(i<(int)size){
            *((uint8_t*)buffer) = input_getc();
            ++buffer;
        }
        lock_release(&file_lock);
        return i;
    }
    else{
        if(is_kernel_vaddr(buffer)){
            lock_release(&file_lock);
            thread_exit(-1);
        }

        if(!pagedir_get_page(thread_current()->pagedir, buffer))
        {
            lock_release(&file_lock);
            thread_exit(-1);
        }
        if(thread_current()->fd[fd] == NULL){
            lock_release(&file_lock);
            return -1;
        }
           else{
               i = file_read(thread_current()->fd[fd], buffer, size);
               lock_release(&file_lock);
               return i;
           }
    }
}

int write(int fd, const void *buffer, unsigned size){

    int i = 0;
    lock_acquire(&file_lock);
    if(fd == STDIN_FILENO){
        lock_release(&file_lock);
        thread_exit(-1);
    }

    else if(fd == STDOUT_FILENO){
        putbuf((const char*)buffer, size);
        lock_release(&file_lock);
        return size;
    }

    else{
        if(is_kernel_vaddr(buffer)){
            thread_exit(-1);
        }
        if(!pagedir_get_page(thread_current()->pagedir, buffer)){
            lock_release(&file_lock);
            thread_exit(-1);
        }

        if(thread_current()->fd[fd]==NULL){
            lock_release(&file_lock);
            return -1;
        }

        else{
            if(thread_current()->fd[fd]->deny_write)
                file_deny_write(thread_current()->fd[fd]);
            i = file_write(thread_current()->fd[fd], buffer, size);
            lock_release(&file_lock);
            return i;
        }
    }
}

void check_user_vaddr(const void *vaddr){
    if(!is_user_vaddr(vaddr)){
        thread_exit(-1);
    }
}

int pibonacci(int n){
    if(n==0)
        return 0;
    else if(n==1)
        return 1;
    else
        return pibonacci(n-1) + pibonacci(n-2);
}

int sum_of_four_integers(int a,int b,int c,int d){
    return a+b+c+d;
}


int syscall_create(const char* file, unsigned initial_size){
    bool success;
      if(!file || is_kernel_vaddr(file)||!pagedir_get_page(thread_current()->pagedir,file)){
        thread_exit(-1);
    }
 
    lock_acquire(&file_lock);
    success = filesys_create(file, initial_size);
    lock_release(&file_lock);

    return success;
}

int open(const char* file){
    struct thread* cur;
    struct file *fp;
    int i;

    cur = thread_current();
    if(file == NULL || is_kernel_vaddr(file) || !pagedir_get_page(cur->pagedir, file))
        thread_exit(-1);

    lock_acquire(&file_lock);

    if((fp = filesys_open(file)) == NULL) i = -1;
    else {
        for(i=3; i<128; i++){
            if(thread_current()->fd[i] == NULL){
                if(strcmp(thread_current()->name, file)==0)
                    file_deny_write(fp);
                thread_current()->fd[i] = fp;
                break;
            }
        } 
    }

    lock_release(&file_lock);
    return i;
}

void close (int fd){
    struct file *fp;

       if(thread_current()->fd[fd] == NULL) thread_exit(-1);
    lock_acquire(&file_lock);

    fp = thread_current()->fd[fd];
    thread_current()->fd[fd] = NULL;
    file_close(fp);

    lock_release(&file_lock);

    return;
}

int filesize(int fd){
    int size;
    
    if(thread_current()->fd[fd] == NULL){
        thread_exit(-1);
    }
    lock_acquire(&file_lock);
    size = file_length(thread_current()->fd[fd]);
    lock_release(&file_lock);

    return size;
}


